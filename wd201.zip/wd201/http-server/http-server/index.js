// Load users from localStorage and display them
    function loadUsers() {
      const users = JSON.parse(localStorage.getItem('users') || '[]');
      const tableBody = document.querySelector('#userTable tbody');
      tableBody.innerHTML = '';
      users.forEach(user => {
        const newRow = tableBody.insertRow();
        newRow.insertCell(0).textContent = user.name;
        newRow.insertCell(1).textContent = user.email;
        newRow.insertCell(2).textContent = user.password;
        newRow.insertCell(3).textContent = user.dob;
        newRow.insertCell(4).textContent = user.acceptTerms ? 'Yes' : 'No';
      });
    }

    function handleSubmit(event) {
      event.preventDefault();
      
      const name = document.getElementById('name').value;
      const email = document.getElementById('email').value;
      const password = document.getElementById('password').value;
      const dob = document.getElementById('dob').value;
      const acceptTerms = document.getElementById('acceptTerms').checked;

      // Save to localStorage
      const users = JSON.parse(localStorage.getItem('users') || '[]');
      users.push({ name, email, password, dob, acceptTerms });
      localStorage.setItem('users', JSON.stringify(users));

      loadUsers();

      // Reset form
      document.getElementById('registrationForm').reset();
    }

    // Load users on page load
    window.onload = loadUsers;